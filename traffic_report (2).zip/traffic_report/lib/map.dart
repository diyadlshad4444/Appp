import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';


class MapPage extends StatefulWidget {
  final String title;
  final bool isMapButtonVisible;
  final bool isGoogleMapButtonEnabled;
  final String buttonText;

  MapPage({
    required this.title,
    this.isMapButtonVisible = true,
    this.isGoogleMapButtonEnabled = true,
    required this.buttonText,
  });

  @override
  _MapPageState createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  LatLng? currentLocation;
  Marker? currentMarker;

  @override
  void initState() {
    super.initState();
    _initializeLocation();
  }

  Future<void> _initializeLocation() async {
    await _determinePosition();
    if (currentLocation != null) {
      setState(() {
        currentMarker = _createMarker(currentLocation!);
      });
    }
  }

  Future<void> _determinePosition() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      Navigator.pop(context);
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        Navigator.pop(context);
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      Navigator.pop(context);
      return;
    }

    Position position = await Geolocator.getCurrentPosition();
    setState(() {
      currentLocation = LatLng(position.latitude, position.longitude);
      currentMarker = _createMarker(currentLocation!);
    });
  }

  Marker _createMarker(LatLng position) {
    return Marker(
      point: position,
      child: const Icon(
        Icons.location_on,
        size: 50,
        color: Colors.red,
      ),
    );
  }

  void _updateLocation(LatLng latLng) {
    setState(() {
      currentMarker = _createMarker(latLng);
      currentLocation = latLng;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                FlutterMap(
                  options: MapOptions(
                    initialCenter: currentLocation ?? LatLng(35.566864, 45.416107),
                    initialZoom: 17,
                    maxZoom: 18,
                    onTap: (tapPosition, point) {
                      _updateLocation(point);
                    },
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    ),
                    if (currentMarker != null) MarkerLayer(markers: [currentMarker!]),
                  ],
                ),
                if (widget.isGoogleMapButtonEnabled)
                  Positioned(
                    right: 20,
                    top: 40,
                    child: IconButton(
                      icon: const Icon(Icons.map, size: 50, color: Colors.blue),
                      onPressed: () async {
                        if (currentLocation != null) {
                          final latitude = currentLocation!.latitude;
                          final longitude = currentLocation!.longitude;
                          final googleMapsUrl = Uri.parse('geo:$latitude,$longitude?q=$latitude,$longitude');
                          final fallbackUrl = Uri.parse('https://www.google.com/maps/search/?api=1&query=$latitude,$longitude');

                          if (await canLaunchUrl(googleMapsUrl)) {
                            await launchUrl(googleMapsUrl);
                          } else {
                            await launchUrl(fallbackUrl);
                          }
                        }
                      },
                    ),
                  ),
                if (widget.isMapButtonVisible)
                  Positioned(
                    right: 20,
                    bottom: 20,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text(widget.buttonText),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
