import 'package:flutter/material.dart';
import 'package:traffic_report/map.dart';
import 'package:traffic_report/profile.dart';
import 'package:traffic_report/home.dart';
import 'camera.dart';

class NewRequest extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 240, 243, 67),
        title: Center(
          child: Text(
            'داواکاری نوێ',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: () {
                  print('Open Camera');
                },
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.grey[300],
                      child: Icon(
                        Icons.camera_alt,
                        size: 50,
                        color: Colors.black54,
                      ),
                    ),
                    SizedBox(height: 8),
                    ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => CameraScreen()),
                          );
                        },
                        child: Text('کردنەوەی کامێرا'))
                  ],
                ),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    textDirection: TextDirection.rtl,
                    'جۆری کێشە:',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                ),
                isExpanded:
                    true, // Ensures full-width dropdown for better alignment
                items: [
                  DropdownMenuItem(
                    value: 'poor_coloring',
                    child: Directionality(
                      textDirection:
                          TextDirection.rtl, // Ensures text flows right to left
                      child: Text('ڕەنگکردنەوەی نادروست',
                          textAlign: TextAlign.right),
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'illegal_parking',
                    child: Directionality(
                      textDirection: TextDirection.rtl,
                      child: Text('وەستان لە شوێنە نەگونجاوەکان',
                          textAlign: TextAlign.right),
                    ),
                  ),
                  DropdownMenuItem(
                    value: 'traffic_lights_glitch',
                    child: Directionality(
                      textDirection: TextDirection.rtl,
                      child: Text('کێشەی بەرنامەی چراغی هاتوچۆ',
                          textAlign: TextAlign.right),
                    ),
                  ),
                ],
                onChanged: (value) {
                  print('کێشەی هەڵبژێردراو: $value');
                },
                hint: Directionality(
                  textDirection: TextDirection.rtl,
                  child: Text('کێشە دیاری بکە', textAlign: TextAlign.right),
                ),
                dropdownColor:
                    Colors.white, // Optional: Makes dropdown background white
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    textDirection: TextDirection.rtl,
                    'پێناسە:',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 10),
              TextField(
                maxLines: 4,
                textAlign: TextAlign.right, // Aligns text to the right
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'پێناسە دابنێ',
                  hintTextDirection: TextDirection
                      .rtl, // Ensures hint text is also right-aligned
                ),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    textDirection: TextDirection.rtl,
                    'شوێن:',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                ),
                items: [
                  DropdownMenuItem(
                    value: 'Sulaymaniyah',
                    child: Text('Sulaymaniyah'),
                  ),
                  DropdownMenuItem(
                    value: 'Erbil',
                    child: Text('Erbil'),
                  ),
                  DropdownMenuItem(
                    value: 'Karkuk',
                    child: Text('Karkuk'),
                  ),
                  DropdownMenuItem(
                    value: 'Zakho',
                    child: Text('Zakho'),
                  ),
                ],
                onChanged: (value) {
                  print('Selected location: $value');
                },
                hint: Text('شوێن دیاریبکە'),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    textDirection: TextDirection.rtl,
                    'گەڕەک:',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 10),
              TextField(
                textAlign: TextAlign.right,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'گەڕەک دابنێ',
                ),
              ),
              SizedBox(height: 20),
              Container(
                alignment: Alignment.bottomRight,
                child: Text(
                  textDirection: TextDirection.rtl,
                  ('شوێنەکەت دیاری بکە:'),
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              InkWell(
                onTap: () async {
                  final selectedLocation = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MapPage(
                        title: 'select',
                        buttonText: 'Select Location',
                        isMapButtonVisible: true,
                      ),
                    ),
                  );

                  if (selectedLocation != null) {
                    // Handle the returned location (LatLng)
                    print(
                        "Selected Location: ${selectedLocation.latitude}, ${selectedLocation.longitude}");
                  }
                },
                child: Container(
                  decoration:
                      BoxDecoration(borderRadius: BorderRadius.circular(20)),
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 1.2 / 6,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.asset(
                      'images/map.png',
                      width: MediaQuery.of(context).size.width,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 15,
              ),
              ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("بەسەرکەوتوویی پۆست کرا"),
                      duration: Duration(hours: 1),
                      action: SnackBarAction(
                          label: 'باشە',
                          onPressed: () {
                            ScaffoldMessenger.of(context).hideCurrentSnackBar();
                          })));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 240, 243, 67),
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                ),
                child: Text(
                  'پۆست',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        selectedItemColor: const Color.fromARGB(255, 240, 243, 67),
        unselectedItemColor: Colors.grey,
        currentIndex: 1,
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => Reportlist()));
          } else if (index == 1) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => NewRequest()));
          } else if (index == 2) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => pscreen()));
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'سەرەکی',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            label: 'داواکاری نوێ',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'پرۆفایل',
          ),
        ],
      ),
    );
  }
}
