import 'package:flutter/material.dart';
import 'package:traffic_report/new_request.dart';
import 'package:traffic_report/profile.dart';

class Reportlist extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          decoration: InputDecoration(
            hintText: 'گەڕان',
            prefixIcon: Icon(Icons.search),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            filled: true,
            fillColor: Colors.white,
          ),
        ),
        backgroundColor: const Color.fromARGB(255, 240, 243, 67),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            ListTile(
              leading: Icon(Icons.info),
              title: Text('دەربارە'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.notifications),
              title: Text('ئاگادارکردنەوە'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(Icons.help),
              title: Text('یارمەتی'),
              onTap: () {},
            ),
            ListTile(
              leading: Icon(
                Icons.logout,
                color: Colors.red,
              ),
              title: Text(
                'چوونەدەرەوە',
                style: TextStyle(color: Colors.red),
              ),
              onTap: () {},
            ),
          ],
        ),
      ),
      body: ListView(
        children: [
          PostItem(
            name: 'مەستان سالار',
            location: 'سلێمانی, عێراق',
            date: 'Jan 18, 2025',
            description: 'کێشەکە لێرە دیاریکراوە.',
            profileImageUrl: 'images/ph1.jpg',
            issueImageUrl: 'images/1.jpg',
            status: 'چاوەڕوان',
            statusIcon: Icons.access_time,
            statusColor: Colors.orange,
          ),
          PostItem(
            name: 'دییە دلشاد',
            location: 'هەولێر, عێراق',
            date: 'Jan 4, 2025',
            description: 'کێشەیەکی تر لێرە دیاریکراوە.',
            profileImageUrl: 'images/ph2.jpg',
            issueImageUrl: 'images/1.jpg',
            status: 'چارەسەر کراوە',
            statusIcon: Icons.check_circle,
            statusColor: Colors.green,
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        selectedItemColor: const Color.fromARGB(255, 240, 243, 67),
        unselectedItemColor: Colors.grey,
        currentIndex: 0,
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => Reportlist()));
          } else if (index == 1) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => NewRequest()));
          } else if (index == 2) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => pscreen()));
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'سەرەکی',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            label: 'داواکاری نوێ',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'پرۆفایل',
          ),
        ],
      ),
    );
  }
}

class PostItem extends StatelessWidget {
  final String name;
  final String location;
  final String date;
  final String description;
  final String profileImageUrl;
  final String issueImageUrl;
  final String? status;
  final IconData? statusIcon;
  final Color? statusColor;

  const PostItem({
    required this.name,
    required this.location,
    required this.date,
    required this.description,
    required this.profileImageUrl,
    required this.issueImageUrl,
    this.status,
    this.statusIcon,
    this.statusColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 2,
            blurRadius: 5,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundImage: AssetImage(profileImageUrl),
                radius: 25,
              ),
              SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Text(location),
                ],
              ),
              Spacer(),
              Text(
                date,
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
          SizedBox(height: 10),
          if (status != null && statusIcon != null) ...[
            Row(
              children: [
                Icon(
                  statusIcon,
                  color: statusColor,
                ),
                SizedBox(width: 5),
                Text(
                  status!,
                  style: TextStyle(
                    color: statusColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
          SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              description,
              textAlign: TextAlign.left, // LTR description
            ),
          ),
          SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(
              issueImageUrl,
              fit: BoxFit.cover,
              width: double.infinity,
              height: 200,
            ),
          ),
        ],
      ),
    );
  }
}
