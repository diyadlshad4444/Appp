import 'package:flutter/material.dart';
import 'package:traffic_report/home.dart';
import 'package:traffic_report/register.dart';
import 'package:traffic_report/verf.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login Screen',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: Directionality(
        textDirection: TextDirection.rtl, // ✅ Set app direction to RTL
        child: const LoginScreen(),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _phoneController = TextEditingController();
  String? _phoneError;

  void _validatePhoneNumber() {
    setState(() {
      if (_phoneController.text.isEmpty) {
        _phoneError = 'تکایە ژمارەی تەلەفۆن بنوسە';
      } else if (_phoneController.text.length != 11) {
        _phoneError = 'ژمارە دەبێت ١١ ژمارە بێت';
      } else {
        _phoneError = null;
      }
    });
  }

  void _login() {
    _validatePhoneNumber();
    if (_phoneError == null) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => PhoneVerificationScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('چوونەژوورەوە'),
        titleTextStyle: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.black,
        ),
        backgroundColor: const Color.fromARGB(255, 240, 243, 67),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'چوونەژوورەوەی بەکارهێنەر',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 40),
            Container(
                alignment: Alignment.topRight,
                child: Text(
                  'ژمارەی تەلەفۆن',
                )),
            SizedBox(
              height: 15,
            ),
            // Phone Number Field (RTL)
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.number,
              maxLength: 11,
              textAlign: TextAlign.right, // ✅ Align text to right
              textDirection: TextDirection.rtl, // ✅ Ensure RTL input
              decoration: InputDecoration(
                hintText: '077* 123 45 67',
                suffixIcon: const Icon(Icons.phone),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                errorText: _phoneError,
              ),
              onChanged: (_) => _validatePhoneNumber(),
            ),

            const SizedBox(height: 20),

            // Login Button
            ElevatedButton(
              onPressed: _login,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 240, 243, 67),
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              child: const Text(
                'چوونەژوورەوه',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Navigate to Registration Page
            TextButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const RegistrationScreen(),
                  ),
                );
              },
              child: const Text(
                "هەژمارت نییه؟ خۆت تۆمار بکه",
                style: TextStyle(color: Colors.black),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
