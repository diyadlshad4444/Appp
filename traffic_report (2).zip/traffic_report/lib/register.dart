import 'package:flutter/material.dart';
import 'package:traffic_report/login.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({Key? key}) : super(key: key);

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  String? _fullNameError;
  String? _phoneError;

  void _validateInputs() {
    setState(() {
      _fullNameError =
          _fullNameController.text.isEmpty ? 'تکایە ناوی دوانی بنوسە' : null;
      _phoneError = _phoneController.text.isEmpty
          ? 'تکایە ژمارەی تەلەفۆن بنوسە'
          : (_phoneController.text.length != 11
              ? 'ژمارە دەبێت ١١ ژمارە بێت'
              : null);
    });
  }

  void _register() {
    _validateInputs();
    if (_fullNameError == null && _phoneError == null) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => LoginScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('تۆمارکردن'),
        titleTextStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        backgroundColor: const Color.fromARGB(255, 240, 243, 67),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'دەستپێبکە',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 30),

              // Full Name TextField
              TextField(
                controller: _fullNameController,
                decoration: InputDecoration(
                  labelText: 'ناوی دوانی',
                  prefixIcon: const Icon(Icons.person),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  errorText: _fullNameError,
                ),
              ),

              const SizedBox(height: 20),

              // Phone Number TextField with hint text
              TextField(
                controller: _phoneController,
                keyboardType: TextInputType.number,
                maxLength: 11,
                decoration: InputDecoration(
                  labelText: 'ژمارەی تەلەفۆن',
                  hintText: '077* 123 45 67', // <-- Added Hint Text
                  prefixIcon: const Icon(Icons.phone),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  errorText: _phoneError,
                ),
              ),

              const SizedBox(height: 30),

              ElevatedButton(
                onPressed: _register,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 240, 243, 67),
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                child: const Text(
                  'تۆمارکردن',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
              ),

              const SizedBox(height: 20),

              TextButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const LoginScreen(),
                    ),
                  );
                },
                child: const Text(
                  "هەژمارەکەت هەیە؟ چووە ژوورەوە",
                  style: TextStyle(color: Colors.black),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
