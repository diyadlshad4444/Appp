import 'dart:io';

class Report {
  final String issueType;
  final String description;
  final String location;
  final String neighborhood;
  final File? image;

  Report({
    required this.issueType,
    required this.description,
    required this.location,
    required this.neighborhood,
    this.image,
  });
}

class UserData {
  String firstName;
  String lastName;
  String email;
  String location;
  List<Report> reports;

  UserData({
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.location,
    this.reports = const [],
  });
}
