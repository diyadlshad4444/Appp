import 'package:flutter/material.dart';
import 'package:pinput/pinput.dart';
import 'package:traffic_report/home.dart';
import 'package:traffic_report/register.dart';

class PhoneVerificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final TextEditingController _pinController = TextEditingController();

    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Icon(
              Icons.lock,
              size: 80,
              color: Colors.black, // Changed to black
            ),
            const SizedBox(height: 20),
            const Text(
              'کۆدی دڵنیایی',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black, // Changed to black
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'ئێمه کۆدی دڵنیایی ناردین بۆ ژمارەکەت\n07701234567',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 20),

            // PIN Input
            Pinput(
              length: 6,
              controller: _pinController,
              keyboardType: TextInputType.number,
              mainAxisAlignment: MainAxisAlignment.center,
              defaultPinTheme: PinTheme(
                width: 50,
                height: 50,
                textStyle: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black, // Changed to black
                ),
                decoration: BoxDecoration(
                  border:
                      Border.all(color: Colors.black), // Changed border color
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 10),

            // Resend Code Button
            TextButton(
              onPressed: () {
                print("Resend Code");
              },
              child: const Text(
                'دووبارە ناردنەوە',
                style: TextStyle(
                    color: Colors.black, fontSize: 16), // Changed to black
              ),
            ),
            const SizedBox(height: 20),

            // Verify Button
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => Reportlist(),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellow, // Changed to yellow
                padding:
                    const EdgeInsets.symmetric(horizontal: 80, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text(
                'چوونەژوورەوە',
                style: TextStyle(
                    fontSize: 18, color: Colors.black), // Changed text to black
              ),
            ),
            const SizedBox(height: 20),

            // Register Button
            TextButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => RegistrationScreen(),
                  ),
                );
              },
              child: const Text(
                'هەژمارەت نیە؟ خۆت تۆمار بکە',
                style: TextStyle(
                    color: Colors.black, fontSize: 14), // Changed to black
              ),
            ),
          ],
        ),
      ),
    );
  }
}
