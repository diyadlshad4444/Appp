import 'package:flutter/material.dart';
import 'package:traffic_report/new_request.dart';
import 'package:traffic_report/home.dart';

class pscreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'پرۆفایل',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 240, 243, 67),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('images/ph1.jpg'),
              ),
              SizedBox(height: 10),
              Text(
                'مەستان سالار',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'mastan@gmail.com',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 10),
              GestureDetector(
                onTap: () {
                  print('هەژمار بەڕێوەبەر بکە');
                },
                child: Text(
                  'هەژمار بەڕێوەبەر بکە',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'ڕاپۆرتەکان',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 10),
              ReportCard(),
              ReportCard(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        selectedItemColor: const Color.fromARGB(255, 240, 243, 67),
        unselectedItemColor: Colors.grey,
        currentIndex: 2,
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => Reportlist()));
          } else if (index == 1) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => NewRequest()));
          } else if (index == 2) {
            Navigator.push(
                context, MaterialPageRoute(builder: (_) => pscreen()));
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'سەرەکی',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            label: 'داواکاری نوێ',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'پرۆفایل',
          ),
        ],
      ),
    );
  }
}

class ReportCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 15,
                  backgroundColor: Colors.grey[300],
                  backgroundImage: AssetImage('images/ph1.jpg'),
                ),
                SizedBox(width: 10),
                Text(
                  'مەستان سالار',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Spacer(),
                Text(
                  'Jan 18, 2025',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              'سلێمانی, عێراق',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 8),
            Text(
              'کێشەکە: کێشەیەک دیاریکراوە، زانیاری زیاتر لە خوارەوە ببینە.',
              style: TextStyle(fontSize: 14),
            ),
            SizedBox(height: 10),
            Image.asset(
              'images/1.jpg',
              height: 150,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ],
        ),
      ),
    );
  }
}
