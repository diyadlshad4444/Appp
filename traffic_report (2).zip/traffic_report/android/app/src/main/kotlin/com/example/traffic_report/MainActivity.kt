package com.example.traffic_report

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
